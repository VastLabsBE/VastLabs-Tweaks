<?php

namespace Info;

use pocketmine\Player;
use pocketmine\Server;

use pocketmine\utils\TextFormat;
use pocketmine\utils\Config;

use pocketmine\item\Item;
use pocketmine\item\enchantment\Enchantment;

use pocketmine\level\Level;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\sound\EndermanTeleportSound;
use pocketmine\level\sound\GhastSound;

use pocketmine\math\Vector3;

use pocketmine\inventory\Inventory;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;

use pocketmine\plugin\PluginBase;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\DataPacketReceiveEvent;

use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;

use CrateUI\Commands\getkey;

class main extends PluginBase implements Listener{
	
	public $prefix = "§l§4Info §7|§f";
	
	public $config;
	
	public $formCount = 0;

	public $forms = [];

	private static $instance;

	public static function getInstance(): Main{
		return self::$instance;
	}	
	
	public function onEnable(){
		self::$instance = $this;
		$this->saveDefaultConfig();
		$this->cfg = $this->getConfig();
	 	$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->notice("
		§e##################################################
		§e############ Plugin By DerGaamerHD100 ############
		§e##################################################
                            ");		
		$this->getLogger()->info("§cLade Info plugin by DerGaamerHD100...");      
		$this->getLogger() ->Info (TextFormat::GREEN. "Das Info plugin by DerGaamerHD100 wurde erfolgreich geladen!");
	}		
	
	public function onDisable(){
	    $this->getLogger()->info("§cDisabled.");
	}

	public function createCustomForm(callable $function = null) : CustomForm {
		$this->formCount++;
		$form = new CustomForm($this->formCount, $function);
		if($function !== null){
			$this->forms[$this->formCount] = $form;
		}
		return $form;
	}

	public function createSimpleForm(callable $function = null) : SimpleForm {
		$this->formCount++;
		$form = new SimpleForm($this->formCount, $function);
		if($function !== null){
			$this->forms[$this->formCount] = $form;
		}
		return $form;
	}

	public function onPacketReceived(DataPacketReceiveEvent $ev) : void {
		$pk = $ev->getPacket();
		if($pk instanceof ModalFormResponsePacket){
			$player = $ev->getPlayer();
			$formId = $pk->formId;
			$data = json_decode($pk->formData, true);
			if(isset($this->forms[$formId])){
				/** @var Form $form */
				$form = $this->forms[$formId];
				if(!$form->isRecipient($player)){
					return;
				}
				$callable = $form->getCallable();
				if(!is_array($data)){
					$data = [$data];
				}
				if($callable !== null) {
					$callable($ev->getPlayer(), $data);
				}
				unset($this->forms[$formId]);
				$ev->setCancelled();
			}
		}
	}

	public function onPlayerQuit(PlayerQuitEvent $ev){
		$player = $ev->getPlayer();
		/**
		 * @var int $id
		 * @var Form $form
		 */
		foreach($this->forms as $id => $form){
			if($form->isRecipient($player)){
				unset($this->forms[$id]);
				break;
			}
		}
	}	

	public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool{
	     if($cmd->getName() == "info"){
			if(isset($args[0])){
				$sender->sendMessage(TextFormat::GRAY . "--== " . TextFormat::YELLOW . "InfoUI" . TextFormat::GRAY . " ==--");
				$sender->sendMessage(TextFormat::GREEN."Entwickler: InfoUI by DerGamerHD100!\n§4Mach einfach nur /Info!!!!");
				$sender->sendMessage(TextFormat::GRAY . "---======0======---");
				return false;
			} 
			 
			 if($sender instanceof Player){
				$form = $this->createSimpleForm(function (Player $sender, array $data) {
					$result = $data[0];
					if ($result === null) {
					}
					switch ($result) {
						case 1:
							//SErverinfos
							$inv = $sender->getInventory();
								$level = $sender->getLevel();
								$x = $sender->getX();
								$y = $sender->getY();
								$z = $sender->getZ();
								$pos = new Vector3($x, $y + 2, $z);
								$pos1 = new Vector3($x, $y, $z);
								$name = $sender->getName();
								$prefix = $this->cfg->get("Prefix");
								$level->addSound(new EndermanTeleportSound($pos1));
								$level->addParticle(new LavaParticle($pos1));
								$sender->addTitle("§eÖffne", "Server Info!");
								$result = rand(1, 1);
									 switch($result){
							case 1:
								$sender->sendMessage(TextFormat::GRAY . "--== " . TextFormat::YELLOW . "Server Infos" . TextFormat::GRAY . " ==--");
								$sender->sendMessage("§e+§r Wir sind in der BETA!");
								$sender->sendMessage("§e+§r Buggs usw werden behoben!");
								$sender->sendMessage(TextFormat::GRAY . "---======0======---");
								break;
								}
							break;
						case 2:
							//command infos
							$inv = $sender->getInventory();
								$level = $sender->getLevel();
								$x = $sender->getX();
								$y = $sender->getY();
								$z = $sender->getZ();
								$pos = new Vector3($x, $y + 2, $z);
								$pos1 = new Vector3($x, $y, $z);
								$name = $sender->getName();
								$prefix = ("Prefix");
								$level->addSound(new EndermanTeleportSound($pos1));
								$level->addParticle(new LavaParticle($pos1));
								$sender->addTitle("§eÖffne", "Command Infos!");
								$result = rand(1, 1);
									 switch($result){
							case 1:
								$sender->sendMessage(TextFormat::GRAY . "--== " . TextFormat::YELLOW . "Command Infos" . TextFormat::GRAY . " ==--");
								$sender->sendMessage("§e+§r Mach /crate um key einzulösen!");
								$sender->sendMessage("§e+§r Mit /Shop kann man Items kaufen");
								$sender->sendMessage("§e+§r Mit /job list sieht du alle jobs und kann geld verdienen");
								$sender->sendMessage("§e+§r Mit /sell hand oder all kannst du deine item verkaufen!!");
								$sender->sendMessage("§e+§r Mit /Maskshop kannst du dir kopfe kaufen!");
								$sender->sendMessage("§e+§r Mit /vote kannst du wenn du gevotet hast sachen und ein key bekommen!");
								$sender->sendMessage(TextFormat::GRAY . "---======0======---");
								break;
								}
							break;
						case 3:
							//Kauf Ränge
							$inv = $sender->getInventory();
								$level = $sender->getLevel();
								$x = $sender->getX();
								$y = $sender->getY();
								$z = $sender->getZ();
								$pos = new Vector3($x, $y + 2, $z);
								$pos1 = new Vector3($x, $y, $z);
								$name = $sender->getName();
								$prefix = ("Prefix");
								$level->addSound(new EndermanTeleportSound($pos1));
								$level->addParticle(new LavaParticle($pos1));
								$sender->addTitle("§eÖffne", "Kauf Ränge Info!");
								$result = rand(1, 1);
									 switch($result){
							case 1:
								$sender->sendMessage(TextFormat::GRAY . "--== " . TextFormat::YELLOW . "Kauf Ränge Infos" . TextFormat::GRAY . " ==--");
								$sender->sendMessage("§e+§r Derzeit kann man nur Ränge Gewinnen!");
								$sender->sendMessage(TextFormat::GRAY . "---======0======---");
								break;
								}
							break;
						case 4:
							//ts/discord
							$inv = $sender->getInventory();
								$level = $sender->getLevel();
								$x = $sender->getX();
								$y = $sender->getY();
								$z = $sender->getZ();
								$pos = new Vector3($x, $y + 2, $z);
								$pos1 = new Vector3($x, $y, $z);
								$name = $sender->getName();
								$prefix = ("Prefix");
								$level->addSound(new EndermanTeleportSound($pos1));
								$level->addParticle(new LavaParticle($pos1));
								$sender->addTitle("§eÖffne", "Ts/Discord Link!");
								$result = rand(1, 1);
									 switch($result){
							case 1:
								$sender->sendMessage(TextFormat::GRAY . "--== " . TextFormat::YELLOW . "Ts/Discord" . TextFormat::GRAY . " ==--");
								$sender->sendMessage("§e+§r TS IP -> vastlabs.eu");
								$sender->sendMessage("§e+§r Discord Link ->https://discord.gg/pwSDzjr");
								$sender->sendMessage(TextFormat::GRAY . "---======0======---");
								break;
								}
							break;
						case 5:
							//Events
							$inv = $sender->getInventory();
								$level = $sender->getLevel();
								$x = $sender->getX();
								$y = $sender->getY();
								$z = $sender->getZ();
								$pos = new Vector3($x, $y + 2, $z);
								$pos1 = new Vector3($x, $y, $z);
								$name = $sender->getName();
								$prefix = ("Prefix");
								$level->addSound(new EndermanTeleportSound($pos1));
								$level->addParticle(new LavaParticle($pos1));
								$sender->addTitle("§eÖffne", "Events!");
								$result = rand(1, 1);
									 switch($result){
							case 1:
							    $sender->sendMessage(TextFormat::GRAY . "--== " . TextFormat::YELLOW . "Events" . TextFormat::GRAY . " ==--");
								$sender->sendMessage("§e+§r bald");
								$sender->sendMessage("§e+§r 1.1.2018");
								$sender->sendMessage(TextFormat::GRAY . "---======0======---");
								break;
								}
							break;
							
					}
				});

				$form->setTitle("§bInfos");
				$form->setContent("§eHier giobt es alles infos über den Server!");

				$form->addButton("§4Schließen!", 1, "http://pluspng.com/img-png/cross-mark-red-sign-icon-mark-symbol-cross-720.png");
				$form->addButton("§aServer Infos", 2, "http://www.free-icons-download.net/images/info-icon-63443.png");
				$form->addButton("§cCommand Infos", 3, "http://www.free-icons-download.net/images/info-icon-63443.png");
				$form->addButton("§eKauf Ränge Infos", 4, "http://www.free-icons-download.net/images/info-icon-63443.png");
				$form->addButton("§5Ts/Discord Link", 5, "http://www.free-icons-download.net/images/info-icon-63443.png");
				$form->addButton("§9Events", 6, "http://www.free-icons-download.net/images/info-icon-63443.png");

				$form->sendToPlayer($sender);
			 }else{
				 $sender->sendMessage("§cYou are not In-Game.");
			 }
			 return true;
		}
	}
	
}
