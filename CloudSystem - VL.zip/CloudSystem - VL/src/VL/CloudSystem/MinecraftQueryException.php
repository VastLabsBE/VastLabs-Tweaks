<?php

namespace VL\CloudSystem;

class MinecraftQueryException extends \Exception{

}